INSERT INTO ACCOUNT(account_Id,customer_Id,current_Balance,account_Type,owner_Name)
VALUES (10054546,'CUSTOMER101',1100.00, 'Savings', 'John');
