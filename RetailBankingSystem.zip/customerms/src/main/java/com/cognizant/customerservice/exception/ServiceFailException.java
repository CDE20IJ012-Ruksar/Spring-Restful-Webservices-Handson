package com.cognizant.customerservice.exception;

public class ServiceFailException extends Exception{
	public ServiceFailException(String message)
	{
		super(message);
	}

}
